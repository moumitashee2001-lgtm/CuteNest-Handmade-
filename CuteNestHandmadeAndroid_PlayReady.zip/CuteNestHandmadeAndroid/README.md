# CuteNest Handmade — Android-ready project

This project wraps the current CuteNest Handmade web app in a native Android WebView shell.

## Included
- Baby + Ladies handmade hair-clip catalog
- Cart
- Checkout form
- Local cart/order persistence via WebView DOM storage
- WhatsApp order hand-off
- Category filtering
- CuteNest branding and launcher icon
- Android Studio/Gradle project files

## Requirements
- Android Studio **Quail 4 | 2026.1.4 Patch 1** or newer stable
- JDK **17**
- Android SDK Platform **36**
- Internet connection for Gradle dependency download and WhatsApp links

## Open and build
1. Unzip this project.
2. In Android Studio, choose **Open** and select the `CuteNestHandmadeAndroid` folder.
3. Let Gradle sync finish.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press **Run ▶** to install the debug app.
6. To create a debug APK: **Build → Build APK(s)**.
7. The APK will be under:
   `app/build/outputs/apk/debug/app-debug.apk`

## Release APK
For a distributable release APK:
1. **Build → Generate Signed App Bundle / APK**
2. Select **APK**.
3. Create or select a signing keystore.
4. Choose the `release` variant.
5. Finish the wizard.

Keep the keystore and passwords safe. Do not commit them to Git.

## Change products
The product catalog is currently inside:
`app/src/main/assets/index.html`

Replace product names/prices/emojis there, or later change the app to load a real backend/database.

## Set WhatsApp
Open the app → **Info** → **Business WhatsApp** → enter the number with country code, e.g. `919876543210` → Save.

## Important limitation
This is an APK-ready **prototype**, not a production e-commerce backend. Orders are stored locally on the customer's device and sent to your WhatsApp. For a real business app, the next stage should add:
- cloud product database
- secure admin login
- real customer accounts
- payment gateway
- server-side orders
- order status/notifications
- image uploads
- shipping integration

## WebView security
The app uses `WebViewAssetLoader` to load the bundled HTML through the recommended `https://appassets.androidplatform.net/assets/...` URL and only opens normal web/WhatsApp links externally.


## GitHub Actions build (no local Android SDK required)
The project includes `.github/workflows/build.yml`. Upload the project to a GitHub repository and run:
**Actions → Build CuteNest Android → Run workflow**.

The workflow produces:
- a debug APK for direct phone testing
- a release AAB artifact

For a Play Store production release, create a signed release bundle using your own upload keystore and Play App Signing. Do not put a keystore/password into the repository.
